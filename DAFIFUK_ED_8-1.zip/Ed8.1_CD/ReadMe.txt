*** DAFIF Ed 8.1 ***		

*** ALL NOTICES WHICH PREVIOUSLY APPEARED IN README FILES HAVE BEEN MOVED TO RELEASE STATEMENTS. ***		
		
NGA DIGITAL AERONAUTICAL FLIGHT INFORMATION FILE (DAFIF):		
		
Directory Organization: 		
At the highest level, there are 2 directories and 3 files. The directories are: DAFIF8_1 and DOCS and they each contain subdirectories. The three files are the ALMANAC.GPS, CPYRIGHT and this ReadMe.txt file.	
		
1.  DAFIF8_1 Directory (Subdirectories: DAFIFT, STATS, and T_TRANS; Files: VERSION and WMM.dat):		
		
-DAFIFT subdirectory  (This directory contains 20 folders of tab delimited DAFIF data):		
	APPC  - Appendix C (Tables from the specifications Appendix C)
	ARF   - Air Refueling Routes 	
	ARPT  - Airport Info (Runway, Communications, ILS Components, etc)
	ATS   - Air Traffic Services Routes 	
	BDRY  - Airspace Boundaries (Control zones, Identification zones, etc.)
	HLPT  - Heliport Info (Pad/Runway, Communications, Heliport Navaids)
	HOLD  - Holding Patterns	
	IR    - ICAO Regions (IR layout is the same as Boundaries. The outlines of the ICAO Regions are general and based on the ICAO region code Boundary Idents currently found in DAFIF. This is a basic outline ONLY, and will NOT exactly match the official ICAO Region diagram. Data: We used the ICAO code FH as the default until configuration management can provide a new unique ICAO, i.e. IR. Bdry_ident: FH0xxxx, Type as 1 default, Name: ICAO Region (Official region letter as based on ICAO Region diagram) i.e. ICAO REGION A, Con_Auth: NGA, Loc_Datum: Unknown ""U"", WGS_Datum: WGE. Shape: General ""G"", Coordinates: All coordinates are general; we DID NOT follow country boundaries in detail. We did a general match of FIRs, UIRs, etc)	
	MTR   - Military Training Routes 	
	NAV   - Air Navigational Aids 	
	ORTCA - Off Route Terrain Clearance Altitude	
	PAPP  - RNAV Precision Approach Path Points	
	PJA   - Parachute Jump Areas	
	SUAS  - Special Use Airspace (Dangerous, restricted areas)
	SUPP  - Airport Supplemental data (fuel oil, remarks, services, etc)
	SUPPH - Heliport Supplemental data (fuel oil, remarks, services, etc)
	TRM   - Terminal Instrument Procedures (airport SIDs, STARs & IAPs)	
	TRMH  - Terminal Instrument Procedures (heliport SIDs, STARs & IAPs)
	VFR   - Visual Flight Rules (Arrival/Departure Routes for Korea/Germany)	
	WPT   - Waypoints	
		
-STATS subdirectory: 		
	CRCDAFIFT.TXT (We used the standard CRC-32 algorithm standards. Based on the following Little-Endian polynomial: X^32+X^26+X^23+X^22+X^16+X^12+X^11+X^10+X^8+X^7+X^5+X^4+X^2+X+1)(Line feed (Decimal 10 and Hexadecimal 0A) and/or carriage return (Decimal 13 and Hexadecimal 0D) are included in the calculation. The tab files are variable length records written to a text file).	
	DAFIFT.STA files (Contains transaction totals for the DAFIFT files)	
		
-T_TRANS subdirectory:		
	This directory contains 19 folders of transaction files (There are no transactions for IR).	
		
-VERSION file: 		
	This is a small, standard ASCII text file that indicates the version of the data set.
		
	Version file: Edition 8.1	
	Version is a 28 character numerical string. 	
	EXAMPLE DAFIF 8.1:	
	1911101020190611201981112017
		
	A. ddmmyyyy �Revision includes Spanish Airspace Updates�	
	Position 1-4 - Production Cycle - i.e. 1105	
	Position 5-12 - Effective Date - DDMMYYYY	
	Position 13-20 - Expiration Date - DDMMYYYY	
	Position 21-22 - Specification Edition - i.e. 81	
	Position 23-28 - Specification Date - MMYYYY	
		
	OUT OF CYCLE UPDATE FORMAT - DAFIF 8.0 and 8.1	
	Position 1 Mid Cycle Update Version, i.e., A, B, C, etc.
	Position 2-3 ". " A Period and a Space
	Position 4-11 Release Date - The Date the Revised Data Becomes Effective	
	Position 12 Blank	
	Position 13-N Description of Release	
		
-WMM.DAT file:		
	Requests for the magnetic model, data, charts or other magnetic information should be addressed to:
		
	National geophysical Data Center	
	World Data Center - A (Geomagnetism)	
	NOAA EGC 1	
	325 Broadway	
	Boulder CO 80303	
	(303)497-6478   Fax(303)497-6513 	
	http://www.ngdc.noaa.gov/geomag/WMM/DoDWMM.shtml

-WMM_CRC.TXT file (We used the standard CRC-32 algorithm standards. Based on the following Little-Endian polynomial: X^32+X^26+X^23+X^22+X^16+X^12+X^11+X^10+X^8+X^7+X^5+X^4+X^2+X+1)(Line feed (Decimal 10 and Hexadecimal 0A) and/or carriage return (Decimal 13 and Hexadecimal 0D) are included in the calculation. The tab files are variable length records written to a text file).		
		
		
2.  DOCS Directory (this directory contains relevant documents for the DAFIF product):		
		
- Type 1 LOA (As of July 2019, DAFIF has a type I, CNSATM (DO-200B) certification for level 2 (essential) data.  Type 1 LOA CNS/ATM audits are currently administered by the FAA)
		
- DAFIF Configuration Management Report (report that includes all changes/modifications to the DAFIF specification and/or DAFIF output)		
		
		
3. ALMANAC.GPS File (This file consists of orbit parameters for each GPS vehicle, on a weekly epoch - YUMA format, transfer protocol: ASCII only, no control codes):
	The GPS almanac is retrieved from the United States Coast Guard Navigation Center website located here: http://www.navcen.uscg.gov/?pageName=gpsAlmanacs	
	The ASCII text file consists of 15 lines for each vehicle, first line descriptive header, 13 lines of values ending with a blank line, and is self-explanatory. This is NOT a NGA product and is provided for information only.
	The GPS almanac is retrieved approximately three weeks before the AIRAC effective date. The GPS data is updated weekly so users of this data should evaluate and understand the consequences of using outdated data.	
		
4. CPYRIGHT File: 		
	This text file contains pertinent information regarding Copyright, release, distribution, handling, and storage of the DAFIF data.
		
5. ReadMe.txt File: 		
	This is the file you are now reading. It is a standard ASCII text file which can be accessed and printed by most text editors or word processors.There were a series of underscores added to the following file in the DOCS file It should not affect anything: DAFIF Terminal Procedure Exclusion Rules,FAA Type 1 LOA 8.0-8.1,DAFIF 8.1 Data Dictionary v4.1, DAFIF 8.1 Specification v4.1, 8.1 Linked Database Readme, DAFIF Distribution of Assurance Level 1 (critical) data,Folders:Linked Database

9. DAFIF Release Statement:
	This file is inform the user of current LOA Status, and data deviations and/or alterations that do not meet the DAFIF specification. 	
