The DAFIF 8.1 Data Model is generated directly from the DAFIF data for visualization of data relationships.  
The �DataModel_AllTables.pdf� is a DAFIF Table Layout file that includes all the tables with associated columns included in DAFIF.  This report also includes applicable information about each column like primary key (PK) and foreign key (FK). 
In addition, the "DataModel_AllDiagrams" is a file with diagrams for each DAFIFT folder that shows data relationships between tables.


*** NOTICE:  The "Terminal_Procedure_Airport" (referring to TRM folder) and the "Terminal_Procedure_Heliport" (referring to TRMH folder) diagrams reference "PAR_IDENT" as the Primary Key because the table names are exactly the same in each folder.  In these diagrams "PAR_IDENT" is referring to "ARPT_IDENT" and "HELI_IDENT" respectively.
*** NOTICE:  There is no relationship defined between the PAPP record and the TRM_SEG record despite the fact that PAPP\TRM_IDENT is sourced from the TRM_SEG table.  This is because of a missing key field ("PROC") in the PAPP record.  This is most likely due to the fact that ALL PAPP records are PROC=3.
*** NOTICE:  There is no relationship defined between the HOLD record and the TRM record.  This is because of a missing key field ("DUP") in the TRM_SEG record.  This is because "DUP" defines the type of procedure and that information is already captured in TRM_SEG with "PROC".


Tables:
PK=Primary Key
FK=Foreign Key
M=Manddatory (Not NULL)

Diagrams:
P=Primary Key
F=Foreign Key
PF=Primary and Foreign Key
Solid Line = means a required relationship
Dotted Line = means optional relationship


